نسخة مستقلة مصححة من نموذج 2.

تم إصلاح اسم الحزمة الحقيقي داخل app/build.gradle:
applicationId 'com.walhero.siramowathaba.model2'

ملاحظة:
- بقي namespace كما هو حتى لا يتأثر كود MainActivity.
- اسم الحزمة الذي يستعمله Android عند التثبيت هو applicationId.
- هذه النسخة يجب أن تتنصّب بجانب النسخة القديمة ولا تعوّضها.

اسم التطبيق الظاهر:
منظومة السيرة والمواظبة 2
