إصدار v11: ربط نموذج 2 v10 بـ Firebase Firestore.

المشروع المستخدم:
projectId = sira-mowathaba-v2

ما أضيف:
- زر رفع البيانات إلى Firebase.
- زر استرجاع من Firebase.
- عند فتح الرابط/نسخة ويب لأول مرة وكانت الذاكرة المحلية فارغة، يحاول التطبيق استرجاع البيانات تلقائيًا من Firebase.
- الحفظ المحلي بقي كما هو، ولم يتم حذف localStorage.
- المزامنة تحفظ مفاتيح localStorage الخاصة بالتطبيق: sira_* و abs_*.
- البيانات تحفظ في Firestore تحت المسار: institutions / sira2 / state / main مع chunks عند الحاجة.

لم يتم تغيير نموذج 2 v35، ولا الطباعة، ولا بطاقة السيرة، ولا الزوم، ولا إصلاحات v10.
نفس applicationId ونفس مفتاح التوقيع الثابت.
versionCode = 11
versionName = 2.0
