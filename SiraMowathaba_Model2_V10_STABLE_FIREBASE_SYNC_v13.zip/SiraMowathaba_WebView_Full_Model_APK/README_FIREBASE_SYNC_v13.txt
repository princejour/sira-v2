نسخة مستقرة v13 مبنية على SiraMowathaba_Model2_V10_CLEAN_ROLLBACK_VERSION12.
تم فقط دمج أزرار Firebase المجربة: رفع إلى Firebase / استرجاع من Firebase.
تم الحفاظ على applicationId الأصلي: com.walhero.siramowathaba.model2 حتى تقبل التثبيت كتحديث.
تم رفع versionCode إلى 13.
لم يتم تغيير منطق الطباعة أو السجلات أو زر قائمة التلاميذ الجانبية.
