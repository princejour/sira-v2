نسخة نموذج 2 بحزمة مستقلة ومفتاح توقيع ثابت.

applicationId:
com.walhero.siramowathaba.model2

ملف التوقيع الثابت:
app/keystore/sira2-release.jks

بيانات التوقيع:
storePassword = sira2Walid2026!
keyAlias = sira2
keyPassword = sira2Walid2026!

المهم:
- أول APK يتم بناؤه من هذه النسخة يمكن تحديثه لاحقًا بشرط استعمال نفس applicationId ونفس ملف sira2-release.jks.
- لا تحذف ملف app/keystore/sira2-release.jks من GitHub إذا أردت أن تعمل التحديثات القادمة كـ mise à jour.
- هذه الطريقة مناسبة لاستعمال شخصي/تجريبي. إذا كان المستودع عامًا فالأكثر أمانًا استعمال GitHub Secrets بدل وضع المفتاح داخل المشروع.
